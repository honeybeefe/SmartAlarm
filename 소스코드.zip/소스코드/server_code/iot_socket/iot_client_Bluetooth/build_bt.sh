#sudo apt-get install libbluetooth-dev
gcc iot_client_bluetooth.c -o iot_client_bluetooth -lbluetooth -pthread
